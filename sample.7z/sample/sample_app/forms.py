from django import forms
from .models import category, subcategory

class Catform(forms.ModelForm):
    class Meta:
        model = category
        fields = ('id', 'category')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['city'].queryset = City.objects.none()