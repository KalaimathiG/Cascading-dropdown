from django.contrib import admin
from sample_app.models import category,subcategory

from import_export.admin import ImportExportModelAdmin



#admin.site.register(category)
#admin.site.register(subcategory)


@admin.register(category,subcategory)
class ViewAdmin(ImportExportModelAdmin):
    pass


    

# Register your models here.
