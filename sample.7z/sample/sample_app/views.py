from django.shortcuts import render
from django.http import HttpResponse
from sample_app.models import category,subcategory
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView



def form_view(request):
    content=category.objects.order_by('id')
    content2=subcategory.objects.order_by('catid')
    di={"record":content,"record_2":content2}
    return render(request,'sample_app/form_page.html',context=di)

#class ListView(ListView):
 #   model = selectedobject
  #  context_object_name = 'object'

#class CreateView(CreateView):
#    model = selectedobject
 #   fields = ('id', 'categories', 'subcategory')
  #  success_url = reverse_lazy('changelist')

#class UpdateView(UpdateView):
 #   model = selectedobject
  #  fields = ('name', 'birthdate', 'country', 'city')
   # success_url = reverse_lazy('changelist')




    

# Create your views here.
