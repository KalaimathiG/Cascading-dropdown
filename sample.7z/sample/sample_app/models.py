from django.db import models

class category(models.Model):
    id=models.IntegerField(primary_key=True)
    categories=models.CharField(max_length=264)
    
    def __str__(self):
        return self.categories

class subcategory(models.Model):
    catid=models.ForeignKey(category, on_delete=models.CASCADE)
    subcategory=models.CharField(max_length=264)
    
    def __str__(self):
        return self.subcategory
    
#class selectedobject():
 #   id=models.IntegerField(primary_key=True)
  #  categories=models.CharField(max_length=264)
   # subcategory=models.CharField(max_length=264)
    
    
    #def __str__(self):
     #   return self.name


# Create your models here.
